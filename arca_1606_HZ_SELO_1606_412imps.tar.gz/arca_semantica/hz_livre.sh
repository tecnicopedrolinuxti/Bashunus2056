# já tem o código hz.sh que fizemos
